<?php
    setcookie("usuario");
    setcookie("senha");
    header ("location: login.html")
    ?>